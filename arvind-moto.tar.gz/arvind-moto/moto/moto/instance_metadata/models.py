from moto.core.models import BaseBackend


class InstanceMetadataBackend(BaseBackend):
    pass


instance_metadata_backend = InstanceMetadataBackend()
